@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0UPDATE_INSTALL.ps1" (
    echo Extract all files from the ZIP before running this installer.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_INSTALL.ps1"
if errorlevel 1 (
    echo Update was not completed. Review the message above.
    pause
    exit /b 1
)
endlocal
