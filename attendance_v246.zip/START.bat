@echo off
setlocal
cd /d "%~dp0"
title Attendance Manager v246

echo ==========================================
echo   Attendance Manager v246
echo ==========================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    echo Python launcher found: py
    py -3 "retro_attendance.py"
    if errorlevel 1 goto ERROR
    goto END
)

where python >nul 2>nul
if %errorlevel%==0 (
    echo Python found: python
    python "retro_attendance.py"
    if errorlevel 1 goto ERROR
    goto END
)

echo.
echo [ERROR] Python 3 was not found on this PC.
echo The previous versions of this program also require Python.
echo.
pause
exit /b 1

:ERROR
echo.
echo [ERROR] Program stopped with an error.
echo Please take a screenshot of this black window and send it to ChatGPT.
echo.
pause
exit /b 1

:END
endlocal
