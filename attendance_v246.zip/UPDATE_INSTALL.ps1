﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

function Show-Notice([string]$message, [string]$title = '자동근태관리 업데이트') {
    [System.Windows.Forms.MessageBox]::Show($message, $title) | Out-Null
}

try {
    $answer = [System.Windows.Forms.MessageBox]::Show(
        "자동근태관리 프로그램을 완전히 종료한 뒤 [예]를 누르세요.`n현재 실행하던 폴더의 retro_attendance.py를 선택합니다.",
        'v246 설치 확인',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { exit 1 }

    $picker = New-Object System.Windows.Forms.OpenFileDialog
    $picker.Title = '현재 사용 중인 프로그램 폴더에서 retro_attendance.py 선택'
    $picker.Filter = 'retro_attendance.py|retro_attendance.py'
    $picker.FileName = 'retro_attendance.py'
    $picker.CheckFileExists = $true
    if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 1 }

    $source = Split-Path -Parent $MyInvocation.MyCommand.Path
    $destination = Split-Path -Parent $picker.FileName
    $sourceCode = Join-Path $source 'retro_attendance.py'
    $sourceStart = Join-Path $source 'START.bat'
    $targetCode = Join-Path $destination 'retro_attendance.py'
    $targetStart = Join-Path $destination 'START.bat'
    if (!(Test-Path -LiteralPath $sourceCode) -or !(Test-Path -LiteralPath $sourceStart)) {
        throw '압축을 모두 푼 뒤 설치 도우미를 실행하세요.'
    }

    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "업데이트 대상 폴더:`n$destination`n`n기존 근태 DB는 그대로 두고 코드만 교체합니다. 계속할까요?",
        'v246 설치 위치 확인',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { exit 1 }

    if ([string]::Equals([System.IO.Path]::GetFullPath($source), [System.IO.Path]::GetFullPath($destination), [System.StringComparison]::OrdinalIgnoreCase)) {
        throw '새 압축 해제 폴더를 선택했습니다. 기존 프로그램을 실행하던 원래 폴더의 retro_attendance.py를 선택하세요.'
    }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    Copy-Item -LiteralPath $targetCode -Destination ($targetCode + '.bak_' + $stamp) -ErrorAction Stop
    if (Test-Path -LiteralPath $targetStart) {
        Copy-Item -LiteralPath $targetStart -Destination ($targetStart + '.bak_' + $stamp) -ErrorAction Stop
    }
    Copy-Item -LiteralPath $sourceCode -Destination $targetCode -Force -ErrorAction Stop
    Copy-Item -LiteralPath $sourceStart -Destination $targetStart -Force -ErrorAction Stop
    $sourceHash = (Get-FileHash -LiteralPath $sourceCode -Algorithm SHA256).Hash
    $targetHash = (Get-FileHash -LiteralPath $targetCode -Algorithm SHA256).Hash
    if ($targetHash -ne $sourceHash) {
        throw '복사 후 파일 검증에 실패했습니다. 프로그램을 종료하고 다시 시도하세요.'
    }
    Show-Notice "v246 업데이트를 완료했습니다.`n프로그램을 다시 실행하면 창 제목에 v246가 표시됩니다.`n기존 attendance.db는 그대로 보존했습니다."
    Start-Process -FilePath $targetStart -WorkingDirectory $destination
} catch {
    [System.Windows.Forms.MessageBox]::Show(
        "업데이트 실패: $($_.Exception.Message)",
        '자동근태관리 업데이트 오류',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}
